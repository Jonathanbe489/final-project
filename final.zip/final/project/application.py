import os
from cs50 import SQL
from flask import Flask, flash, jsonify, redirect, render_template, request, session
from flask_session import Session
from tempfile import mkdtemp
from werkzeug.exceptions import default_exceptions, HTTPException, InternalServerError
from werkzeug.security import check_password_hash, generate_password_hash

from helpers import apology, login_required, lookup, usd

# Configure application
app = Flask(__name__)

# Ensure templates are auto-reloaded
app.config["TEMPLATES_AUTO_RELOAD"] = True

# Ensure responses aren't cached
@app.after_request
def after_request(response):
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Expires"] = 0
    response.headers["Pragma"] = "no-cache"
    return response


# Custom filter
app.jinja_env.filters["usd"] = usd

# Configure session to use filesystem (instead of signed cookies)
app.config["SESSION_FILE_DIR"] = mkdtemp()
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

# Configure CS50 Library to use SQLite database
db = SQL("sqlite:///finance.db")

# Make sure API key is set
if not os.environ.get("API_KEY"):
    raise RuntimeError("API_KEY not set")


@app.route("/")
@login_required
def index():
    """Show portfolio of stocks"""
    db.execute("DELETE FROM user_shares WHERE shares = 0")
    rows = db.execute("SELECT * FROM user_shares WHERE user_id =?", session["user_id"])
    result = [0]*len(rows)
    price = [0]*len(rows)
    value = [0]*len(rows)
    balance = db.execute("SELECT cash FROM users WHERE id = ?", session["user_id"])
    networth = balance[0]["cash"]

    for i, symbol in enumerate(rows):
        stock = rows[i]["symbol"]
        result[i] = lookup(stock)
        price[i] = result[i]["price"]
        print(price[i])
        value[i] = price[i] * rows[i]["shares"]
        print(value[i])
        networth += value[i]

    return render_template("index.html", rows=rows, balance=balance, networth=networth, price=price, value=value)


@app.route("/buy", methods=["GET", "POST"])
@login_required
def buy():

    if request.method == "GET":
        return render_template("buy.html")

    if request.method == "POST":
        # make sure they input a symbol
        if not request.form.get("symbol"):
            return apology("no symbol given")

        quant = request.form.get("shares")
        if quant.isdigit() == False:
            return apology("Must provide an integer")

        # make sure they input a valid number of shares
        shares = int(request.form.get("shares"))

        if shares <= 0:
            return apology("must input positive number of shares")

        results = lookup(str(request.form.get("symbol")))

        # checks to see if the stock symbol is valid
        if results == None:
            return apology("must input valid stock symbol")

        symbol = results["symbol"]
        name = results["name"]
        price = results["price"]
        balance = db.execute("SELECT cash FROM users WHERE id = ?", session["user_id"])
        cost = price*shares

        # make sure the user has enough cash to complete purchase
        if cost > balance[0]["cash"]:
            return apology("you cannot afford this purchase")

        else:
            # execute the transaction
            db.execute("INSERT INTO user_shares (user_id, symbol, shares) VALUES (?,?,?)",
                       session["user_id"], results["symbol"], request.form.get("shares"))

            # add the transaction to transaction history

            datetime = db.execute("SELECT CURRENT_TIMESTAMP")
            db.execute("INSERT INTO history (user_id, type, symbol, price, shares, date) VALUES (?, 'buy', ?, ?, ?, ?)", session["user_id"],
                       symbol, price, shares, datetime[0]["CURRENT_TIMESTAMP"])

            # subtract cost from balance
            balance[0]["cash"] -= cost
            db.execute("UPDATE users SET cash = ? WHERE id = ?", balance[0]["cash"], session["user_id"])

            # here i want to compile all shares into the same row
            total_shares = db.execute("SELECT SUM(shares) from user_shares WHERE user_id = ? AND symbol = ?",
                                      session["user_id"], symbol)
            db.execute("DELETE FROM user_shares WHERE user_id = ? AND symbol = ?", session["user_id"], symbol)
            db.execute("INSERT INTO user_shares (user_id, symbol, shares) VALUES (?,?,?)",
                       session["user_id"], symbol, total_shares[0]["SUM(shares)"])

            # return website
            return redirect("/")


@app.route("/history")
@login_required
def history():
    transactions = db.execute("SELECT * FROM history WHERE user_id = ?", session["user_id"])
    return render_template("history.html", transactions=transactions)


@app.route("/login", methods=["GET", "POST"])
def login():
    """Log user in"""
    # Forget any user_id
    session.clear()

    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":

        # Ensure username was submitted
        if not request.form.get("username"):
            return apology("must provide username", 403)

        # Ensure password was submitted
        elif not request.form.get("password"):
            return apology("must provide password", 403)

        # Query database for username
        rows = db.execute("SELECT * FROM users WHERE username = :username",
                          username=request.form.get("username"))

        # Ensure username exists and password is correct
        if len(rows) != 1 or not check_password_hash(rows[0]["hash"], request.form.get("password")):
            return apology("invalid username and/or password", 403)

        # Remember which user has logged in
        session["user_id"] = rows[0]["id"]

        # Redirect user to home page
        return redirect("/")

    # User reached route via GET (as by clicking a link or via redirect)
    else:
        return render_template("login.html")


@app.route("/logout")
def logout():
    """Log user out"""

    # Forget any user_id
    session.clear()

    # Redirect user to login form
    return redirect("/")


@app.route("/quote", methods=["GET", "POST"])
@login_required
def quote():
    """Get stock quote."""

    if request.method == "GET":
        return render_template("quote.html")

    if request.method == "POST":
        results = lookup(str(request.form.get("symbol")))
        if results == None:
            return apology("must input valid stock symbol")
        else:
            return render_template("quoted.html", symbol=results["symbol"], name=results["name"], price=results["price"])

# This is my personal touch -- an option to add funds
@app.route("/add", methods=["GET", "POST"])
@login_required
def add():
    if request.method == "GET":
        return render_template("add.html")

    if request.method == "POST":

        value = request.form.get("value")

        # makes sure they input a number
        if not value:
            return apology("must provide number", 403)

        # makes sure the number is positive
        if value.isdigit() == False:
            return apology("Must provide an integer")

        if int(value) <= 0:
            return apology("must input positive number")

        else:
            balance = db.execute("SELECT cash FROM users WHERE id = ?", session["user_id"])
            balance[0]["cash"] += int(value)
            db.execute("UPDATE users SET cash = ? WHERE id = ?", balance[0]["cash"], session["user_id"])
            return redirect("/")


@app.route("/register", methods=["GET", "POST"])
def register():
    """Register user"""

    session.clear()

    if request.method == "GET":
        return render_template("register.html")

    if request.method == "POST":
         # Ensure username was submitted
        if not request.form.get("username"):
            return apology("must provide username", 403)

        # check if password matches confirm password
        if request.form.get("password") != request.form.get("confirm password"):
            return apology("passwords must match", 403)

        # Ensure password was submitted
        elif not request.form.get("password"):
            return apology("must provide password", 403)

        rows = db.execute("SELECT * FROM users WHERE username = :username",
                          username=request.form.get("username"))

        if len(rows) > 0:
            return apology("username already taken", 403)

        storedpassword = generate_password_hash(request.form.get("password"))

        db.execute("INSERT INTO users (username, hash) VALUES (:username, :password)",
                   username=request.form.get("username"), password=storedpassword)

        return redirect("/")


@app.route("/sell", methods=["GET", "POST"])
@login_required
def sell():
    """Sell shares of stock"""
    if request.method == "GET":
        return render_template("sell.html")

    if request.method == "POST":
        # make sure they input a symbol
        if not request.form.get("symbol"):
            return apology("no symbol given")

        # make sure they input a valid number of shares
        quant = request.form.get("shares")
        if quant.isdigit() == False:
            return apology("Must provide an integer")

        shares = int(request.form.get("shares"))
        if shares <= 0:
            return apology("must input positive number of shares")

        results = lookup(str(request.form.get("symbol")))

        # checks to see if the stock symbol is valid
        if results == None:
            return apology("must input valid stock symbol")

        symbol = results["symbol"]
        # checks to see if the user actually own this stock
        CHECK = db.execute("SELECT symbol FROM user_shares WHERE symbol = ? AND user_id =?", symbol, session["user_id"])
        if len(CHECK) != 1:
            return apology("you do not own this stock")
        name = results["name"]
        price = results["price"]
        balance = db.execute("SELECT cash FROM users WHERE id = ?", session["user_id"])
        value = price*shares
        total_shares = db.execute("SELECT SUM(shares) from user_shares WHERE user_id = ? AND symbol = ?",
                                  session["user_id"], symbol)
        if shares > total_shares[0]["SUM(shares)"]:
            return apology("you do not own enough shares")

        else:
            # here i want to compile all shares into the same row
            db.execute("DELETE FROM user_shares WHERE user_id = ? AND symbol = ?", session["user_id"], symbol)
            db.execute("INSERT INTO user_shares (user_id, symbol, shares) VALUES (?,?,?)",
                       session["user_id"], symbol, total_shares[0]["SUM(shares)"])

            # subtract number of shares
            total_shares[0]["SUM(shares)"] -= shares
            db.execute("UPDATE user_shares SET shares = ? WHERE user_id = ? and symbol = ?",
                       total_shares[0]["SUM(shares)"], session["user_id"], symbol)

            # add value to cash balance
            balance[0]["cash"] += value
            db.execute("UPDATE users SET cash = ? WHERE id = ?", balance[0]["cash"], session["user_id"])

            # add to transaction log
            datetime = db.execute("SELECT CURRENT_TIMESTAMP")
            db.execute("INSERT INTO history (user_id, type, symbol, price, shares, date) VALUES (?, 'sell', ?, ?, ?, ?)", session["user_id"],
                       symbol, price, shares, datetime[0]["CURRENT_TIMESTAMP"])
            return redirect("/")


def errorhandler(e):
    """Handle error"""
    if not isinstance(e, HTTPException):
        e = InternalServerError()
    return apology(e.name, e.code)


# Listen for errors
for code in default_exceptions:
    app.errorhandler(code)(errorhandler)
